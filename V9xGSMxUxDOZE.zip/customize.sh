MINAPI=12
MAXAPI=34
DEBUG=true

ARCH SDK=`getprop ro.build.version.sdk`

ui_print "

╔══╦══╗╔══╦═╦═╦══╗╔══╦═╦═╦╗─╔╦══╦═╦═╗
║╔═╣══╣║╔═╣║║║║══╣║══╣╦╣╬║╚╦╝╠║║╣╔╣╦╝
║╚╗╠══║║╚╗║║║║╠══║╠══║╩╣╗╬╗║╔╬║║╣╚╣╩╗
╚══╩══╝╚══╩╩═╩╩══╝╚══╩═╩╩╝╚═╝╚══╩═╩═╝  "
ui_print "▌DEVICE INFORMATION: "
sleep 0.2
ui_print "▌DEVICE : $(getprop ro.product.model) "
sleep 0.2
ui_print "▌BRAND : $(getprop ro.product.system.brand) "
sleep 0.2
ui_print "▌MODEL : $(getprop ro.build.product) "
sleep 0.2
ui_print "▌KERNEL : $(uname -r) "
sleep 0.2
ui_print "▌PROCESSOR : $(getprop ro.product.board) "
ui_print "▌Remove Other OPTIMIZER for Better performance,"
ui_print " "
am start -a android.intent.action.VIEW -d https://rb.gy/4gj1x >/dev/null 2>&1 & >/dev/null 2>&1 &
ui_print "▌INSTALLINF GODSPEED UDOZE "
sleep 2
ui_print "▌INSTALLED GODSPEED UDOZE "
ui_print "▌A module by @revWhiteShadow "
ui_print "▌support channel @godTspeed | @godspeedmode "
am start -a android.intent.action.VIEW -d https://t.me/godtspeed >/dev/null 2>&1 & >/dev/null 2>&1 &
sleep 5
am start -a android.intent.action.VIEW -d https://t.me/godspeedmode >/dev/null 2>&1 & >/dev/null 2>&1 &
sleep 5
ui_print "▌Visit Our website for more gaming stuffs "
ui_print "▌www.godtspeed.xyz"
ui_print "▌SettingUp Permissions "
sleep 3
ui_print ""
sleep 1

set_permissions() {
set_perm_recursive $MODPATH/system/bin 0 0 0755 0755
}

##########################################################################################
# MMT Extended Logic - Don't modify anything after this
##########################################################################################

SKIPUNZIP=1
unzip -qjo "$ZIPFILE" 'common/functions.sh' -d $TMPDIR >&2
. $TMPDIR/functions.sh
